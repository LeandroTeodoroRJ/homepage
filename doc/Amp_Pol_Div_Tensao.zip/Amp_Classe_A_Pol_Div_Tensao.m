%************************************************************************
%AMP CLASSE A, POL. DIVISOR DE TENS�O PARA PEQ. SINAIS
%ATZ 20/01/17
%************************************************************************
%-------------------------------------------------------------------------
%NOTAS
%1)Zo=RC para inclus�o no pr�ximo est�gio
%2)Inclu�do mais um ponto no gr�fico de resposta de alta frequ�ncia, sendo
%(100*fc_sup) e suas respectivas imagens.
%-------------------------------------------------------------------------
%FORMATA��O NUM�RICA
format short e %Cinco d�gitos mais expoente
%-------------------------------------------------------------------------
%VARI�VEIS DE ENTRADA
disp(' ')
Rs=input('Rs Fonte [ohm] - ZERO para desprezar: '); %Ex: 800
RL=input('Resistor de Carga [ohm] - Valor alto para desprezar: '); %Ex: 1.6e3
K=input('Cte para c�lculo de R2 [0.01<K<0.1]: '); %Ex: 0.05
hie=input('Input Impedance, zero para c�lculo em estimada: '); %Ex: 0
Vcc=input('Tens�o de alimenta��o [V]: '); %Ex: 12
Ptq=input('Pot�ncia de Trabalho do Transistor[W]: '); %Ex: 0.01
B=input('Beta do Transistor[Admensional](Usar o menor valor de B): '); %Ex: 100
disp('Op��es para o ganho:')
disp('0-> Ganho ac sem Rs e RL')
disp('1-> Ganho ac com Rs')
disp('2-> Ganho ac com Rs e RL')
Ganho=input('Ganho: '); %Ex: 2
fmin=input('Freq. m�nima de corte  [Hz]: '); %Ex: 300
Ft=input('Produto Ganho de Corrente-largura de Banda [Hz]: '); %Ex:100e6
Cc=input('Capacit�ncia parasita de Realimenta��o [F]: '); %Ex: 5e-12
Cstray=input('Capacit�ncia parasita de Fia��o [F]: '); %Ex: 8e-12
%-------------------------------------------------------------------------
%CONSTANTES DO SISTEMA
Ve = 0.1;      	%VE 10% de Vcc
Vce = 0.5;          %VCE 50% de Vcc
Vbe = 0.7;          %Jun��o Vbe[V]
re_ac = 0.025;	%Aproxima��o de re(ac) para 25mV de Ie
f1 = (1/10)*fmin;	%Frequ�ncia de corte a pardir da freq. de opera��o
%-------------------------------------------------------------------------
%MALHA DE SA�DA
VCEq = Vce*Vcc;     %VCE quiescente de opera��o do transistor
Ie = Ptq/VCEq;      %Corrente Ie(dc) em fun��o da pot�ncia dissipada no transistor
VE = Ve*Vcc; 		%C�lculo de RE
RE = VE/Ie; 
PRE = VE*Ie; 		%Pot�ncia em dissipada em RE
VRC = Vcc-VE-VCEq; 	%Tens�o em RC
RC = VRC/Ie; 		%C�lculo de RC
PRC = VRC*Ie; 		%Ptencia em RC
%-------------------------------------------------------------------------
%MALHA DE ENTRADA
R2=K*B*RE;                %C�lculo de R2
VR2=VE+Vbe;
R1=((Vcc-VR2)/VR2)*R2;
PR1=((Vcc-VR2)^2)/R1;     %Pot�ncia em R1
PR2=(VR2^2)/R2;           %Pot�ncia em R2
%-------------------------------------------------------------------------
%C�LCULO AC
re = re_ac/Ie;
Zb = B*re;                      %Imped�ncia de Entrada sem Rs 
Zin = prl3(R1,R2,Zb);

switch Ganho
    case 0                              %0-> Ganho ac sem Rs e RL 
        rc = RL;                        %C�lculo de rc
        Av = rc/re;                     %Ganho sem Rs       
    case 1                              %1-> Ganho ac com Rs 
        rc = RL;                        %C�lculo de rc
        Avnl = rc/re;                   %Ganho sem Rs
        Av = (Zin/(Zin+Rs))*Avnl;       %Ganho com Rs     
    case 2                              %2-> Ganho ac com Rs e RL
        rc = prl(RL,RC);            	%C�lculo de rc
        Avnl = rc/re;                   %Ganho sem Rs
        Av = (Zin/(Zin+Rs))*Avnl;       %Ganho com Rs
end
Av_dB=20*log10(Av);             %Ganho em dB
MPPsup = -Ie*rc+VCEq;       	%Compliance de Corte Superior
%-------------------------------------------------------------------------
%BAIXA FREQU�NCIA
R = Rs+Zin;			 
C1 = 1/((2*3.14)*R*f1); 	%C�lculo de C1
R = RL+RC; 
C2 = 1/((2*3.14)*R*f1); 	%C�lculo de C2
a = prl3(Rs,R1,R2);         %Resist�ncia ca para o gerador
b = (a/B)+re;               %Resist�ncia ca olhando por RE
c = prl(b,RE);              %Paralelo RE||b
CE = 1/((2*3.14)*c*f1); 	%C�lculo de CE
%-------------------------------------------------------------------------
%ALTA FREQU�NCIA
CMin = Cc*(Av+1);                  %Capacit�ncia miller de entrada
Cout = (Cc*(Av+1)/Av)+Cstray;      %Capacit�ncia miller de s�ida + Capacit�ncia parasita de fia��o

Ce = 1/(2*pi*Ft*re);               %Capacit�ncia parasita de Emissor

if (hie == 0)           %Aproxima��o da resist�ncia de base rb do modelo pi de Gigliotto
    rb=0.2*B*re;
else
    rb=hie-B*re;
end

a=prl3(Rs,R1,R2);      %C�lculo de Rin
b=a+rb;                %Resist�ncia de base ac para o modelo pi
c=B*re;                %Resist�ncia de emissor "re" vista pela malha de entrada
Rin=prl(b,c);

Cin=CMin+Ce;             %Capacit�ncia parasita total de entrada 

fc_in=1/(2*3.14*Rin*Cin);     %Frequ�ncia de corte superior pelo circuito de entrada
fc_out=1/(2*3.14*rc*Cout);    %Frequ�ncia de corte superior pelo circuito de sa�da

if (fc_in < fc_out)       %Testa pra ver qual vai cortar primeiro
    fc_sup=fc_in;
else
    fc_sup=fc_out;
end

fmax=0.1*fc_sup;            %Retorna a frequ�ncia m�xima da banda m�dia, sendo 0,1 da frequ�ncia de corte superior

%-------------------------------------------------------------------------

%-------------------------------------------------------------------------
%RESULTADOS
disp('Resultados')

%C�lculo DC
disp('C�lculo DC')
disp(['VCEq = ' num2str(VCEq)]) %Mostrar uma vari�vel ap�s uma string
disp(['Ie = ' num2str(Ie)])
disp(['RE = ' num2str(RE)])
disp(['RC = ' num2str(RC)])
disp(['R1 = ' num2str(R1)])
disp(['R2 = ' num2str(R2)])
disp(['Pot�ncia em RE = ' num2str(PRE)])
disp(['Pot�ncia em RC = ' num2str(PRC)])
disp(['Pot�ncia em R1 = ' num2str(PR1)])
disp(['Pot�ncia em R2 = ' num2str(PR2)])


%C�lculo AC
disp('C�lculo AC')
disp(['Zo = ' num2str(RC)])
disp(['Zin = ' num2str(Zin)])
disp(['Av(ac) = ' num2str(Av)])
disp(['Av(dB) = ' num2str(Av_dB)])
disp(['re = ' num2str(re)])
disp(['MPPsup = ' num2str(MPPsup)])
disp(['C1 = ' num2str(C1)])
disp(['C2 = ' num2str(C2)])
disp(['CE = ' num2str(CE)])
disp(['Frequ�ncia Max Banda = ' num2str(fmax)])

%-------------------------------------------------------------------------
%CURVAS
%Reta cc
x = linspace(0,Vcc,2);
Icc_sat = Vcc/(RC+RE);              %corrente de satura��o dc 
coef = Icc_sat/Vcc;                 %coeficiente angular da reta cc
reta_cc = (-x*coef)+Icc_sat;  		%Eq da reta de carga

%A reta ca passa pelos pontos Q=`(Vce, Ie)*e*Corte_ca = (Ie*Rc_ac, 0)
coef_ca = Ie/(Ie*rc-VCEq);          %coeficiente angular da reta de carga ca
reta_ca = coef_ca*(x-VCEq)+Ie; 
figure;                             %Abre outra janela de gr�fico
plot(x,reta_ca,x,reta_cc);
grid on;                            %Habilita grid do gr�fico
axis([0 Vcc 0 Icc_sat]);            %Limite dos eixos
title('Reta de Carga');             %Formata��o do T�tulo
legend('ca','cc');                  %Formata��o da legenda das curvas
xlabel('VCE');                      %Formata��o do nome do eixo x
ylabel('Ie');                       %Formata��o do nome do eixo y 

%Curva de Bode ALta Frequ�ncia

%Pontos para o eixo das frequ�ncias para curva de Bode e resposta de
%fase: fmax, fc, 2fc, 4fc e 10fc
fx = [(fmax), (fc_sup), (2*fc_sup), (4*fc_sup), (10*fc_sup),(100*fc_sup)];   

%Atenua��o do ganho em fun��o dos pontos em fx.
Avy = Av./(sqrt(1+(fx./fc_sup).^2));
%Resposta de fase em fun��o dos pontos em fx
%Arco da tangente
%Fase_y = 180-atand(fc_sup./fx);
Fase_y = 180-atand(fx./fc_sup);
figure;                             %Abre outra janela de gr�fico
%Escala logaritmica em x
[hAx,hLine1,hLine2] = plotyy(fx,Avy,fx,Fase_y, 'semilogx','semilogx');       


grid on;                            %Habilita grid do gr�fico
title('Resposta em Alta Freq�ncia');%Formata��o do T�tulo
legend('Ganho','Fase');             %Formata��o da legenda das curvas
xlabel('f');                        %Formata��o do nome do eixo x
ylabel(hAx(1),'Av')                 %name for left y-axis
ylabel(hAx(2),'Fase')               %name for right y-axis
