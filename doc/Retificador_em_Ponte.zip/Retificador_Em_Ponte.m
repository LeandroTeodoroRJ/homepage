%-------------------------------------------------------------------------
%RETIFICADOR EM PONTE %ATZ 31/10/16
%-------------------------------------------------------------------------
%NOTAS
%1) Este circuito n�o utiliza o center tap, assim o valor de entrada � a 
%soma dos dois enrolamentos do secund�rio.
%-------------------------------------------------------------------------
%Formata��o num�rica
format shortEng %Cinco d�gitos mais expoente
%-------------------------------------------------------------------------
%Vari�veis de entrada
disp(' ')
Vac=input('Tens�o no enrolamento do secund�rio [Vp]: '); 
Vr=input('Valor da tens�o de riple [0<vr<1]: '); 
f=input('Freq�ncia da rede [Hz]: '); 
IL=input('Corrente na carga [A]: '); 
%-------------------------------------------------------------------------
%Constantes do sistema
%-------------------------------------------------------------------------
fr=2*f;         %Frequ�ncia de retifica��o
VD=0.7;         %Queda de tens�o no diodo retificador
W=2*3.14*fr;     %Velocidade angular
Wrad=2*180*fr;   %W para Pi radianos em 180 graus
T=1/fr;
%-------------------------------------------------------------------------
Vdc=0.636*(Vac-(2*VD));          %Tens�o DC na sa�da
vr_rms=Vr*Vdc;               %Tens�o de ripple em rms
C=0.1443*(IL/(f*vr_rms));   %C�lculo do capacitor de filtro

RL=Vdc/IL;                      %Resistor de carga equivalente
Im=Vdc*sqrt(1/RL^2+W^2*C^2);    %Corrente de pico no diodo [A]
%Tempo de condu��o do diodo
Tf=90/(Wrad);                   %Valor do tempo instant�neo para Vp [s], tempo de condu��o final do diodo
Vr_mim=Vdc-vr_rms;              %Valor m�nimo instant�neo da tens�o de ripple [V]
Ti=(acosd(Vr_mim/Vac))/Wrad;    %Tempo de condu��o inicial do diodo
DTd=Tf-Ti;                      %Intervalo de tempo do diodo conduzindo

%Pot�ncia dissipada no diodo
Imd=(DTd*Im)/(2*T);             %Corrente m�dia do diodo conduzindo (�rea dido conduzindo[aproximado para tri�ngulo] = �rea m�dia)
Pd=VD*Imd;                      %Pot�ncia m�dia dissipada no diodo
T2=T-DTd;
Pdm=VD*IL*T2;
%-------------------------------------------------------------------------
%Resultados
disp(' ')
disp('Resultados')
disp(['Vdc(rms) = ' num2str(Vdc)]) 
disp(['V_ripple(rms) = ' num2str(vr_rms)])
disp(['C1[F] = ' num2str(C)])
disp(['ID pico[A] = ' num2str(Im)]) 
disp(['Pot�ncia de In-Rush no diodo[W] = ' num2str(Pd)])
disp(['Pot�ncia m�dia no diodo[W] = ' num2str(Pdm)])
disp(['Resist�ncia de carga equivalente = ' num2str(RL)])
%-------------------------------------------------------------------------
                     