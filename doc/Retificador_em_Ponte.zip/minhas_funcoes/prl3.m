%Fun��o 3 resistores em paralelo
%
%Retorna o valor de tr�s resistores em paralelo
%
%Exemplo
%
%resultado = prl3(R1,R2,R3)
%
%prl3(10,5,7)

function resultado = prl3(R1,R2,R3)
a=(1/R1)+(1/R2)+(1/R3);
resultado = 1/a;