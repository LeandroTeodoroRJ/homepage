%************************************************************************
%AMP CLASSE A POL. SEGUIDOR DE EMISSOR DE SINAL
%ATZ 13/01/17
%************************************************************************
%NOTAS:
%
%-------------------------------------------------------------------------
%Formata��o num�rica
format short e %Cinco d�gitos mais expoente
%-------------------------------------------------------------------------
%Vari�veis de entrada
%Rs=input('Rs Fonte [ohm] - ZERO para desprezar: '); %Ex 2e3 
RL=input('RL [ohm]: '); %Ex 200
fmin=input('Freq. m�nima de corte [Hz]: '); %Ex 300 
Vcc=input('Tens�o de alimenta��o [V]: '); %Ex 12
B=input('Beta do Transistor[Adimencional], usar o menor valor de B: '); %Ex 100 
%-------------------------------------------------------------------------
%Constantes do sistema
K = 10;              %Cte para c�lculo de R1 e R2 [10<K<100]
Kre = 0.1;           %re(ac) ser� 10% de RL
KVce = 0.5;          %VCE 50% de Vcc
Vbe = 0.7;           %Jun��o Vbe[V]
Kre_ac = 0.025;      %Aproxima��o de re(ac) para 25mV de Ie
f1 = (1/10)*fmin;	 %Frequ�ncia de corte a pardir da freq. de opera��o
%-------------------------------------------------------------------------
%Malha de s�ida
RE = RL;             %Para m�xima transfer�ncia de pot�ncia
VCEq = KVce*Vcc;     %Tens�o VCE quiescente
Ie = VCEq/RE;
re = Kre_ac/Ie;      %Resist�ncia ac de entrada de base
Ptq = VCEq*Ie;
%-------------------------------------------------------------------------
%Malha de entrada
Ib = Ie/B;          %Corrente na Base
I_bias = K*Ib;      %Corrente de polariza��o dos resistores de base
VRb = Vcc/2;        %Tens�o de polariza��o de base
Rb = VRb/I_bias;    %C�lculo de R1 e R2
PRb = VRb*I_bias;   %Pot�ncias de R1 e R2
R1 = Rb;
R2 = Rb;
PR1 = PRb;
PR2 = PRb;
%-------------------------------------------------------------------------
%C�lculo AC
Zb = B*(re+RE);                 %Imped�ncia de Entrada de Base sem Rs 
Zin = prl3(R1,R2,Zb);           %Imped�ncia de Entrada
Zo = prl(re,RE);                %Imped�ncia de sa�da
MPPsup = Vcc-VCEq;            	%Compliance de Corte Superior
%-------------------------------------------------------------------------
%Baixa frequ�ncia
R = Rs+Zin;			 
C1 = 1/((2*3.14)*R*f1); 	%C�lculo de C1
C2 = 1/((2*3.14)*re*f1); 	%C�lculo de C1
%-------------------------------------------------------------------------
%Dados t�rmicos
%
%-------------------------------------------------------------------------
%Resultados
disp(' ')
disp('RESULTADOS')
%C�lculo DC
disp('C�LCULO DC')
disp(['VCEq = ' num2str(VCEq)]) 
disp(['Ie = ' num2str(Ie)])
disp(['RE = ' num2str(RE)])
disp(['R1 = ' num2str(R1)])
disp(['R2 = ' num2str(R2)])
disp(['Pot�ncia em R1 = ' num2str(PR1)])
disp(['Pot�ncia em R2 = ' num2str(PR2)])
%Dados T�rmicos
disp('DADOS T�RMICOS')
disp(['Pot�ncia no transistor = ' num2str(Ptq)])
%C�lculo AC
disp('C�LCULO AC')
disp(['Zin = ' num2str(Zin)])
disp(['MPPsup = ' num2str(MPPsup)])
disp(['C1 = ' num2str(C1)])
disp(['C2 = ' num2str(C2)])
%-------------------------------------------------------------------------
