%-------------------------------------------------------------------------
%AMP CLASSE A, FET CONF. AUTOPOLARIZACAO PARA PEQ. SINAIS
%ATZ 20/01/17
%-------------------------------------------------------------------------
%COMANT�RIOS DO SOFTWARE
%1)Zo=RD para inclus�o no pr�ximo est�gio.
%2)Inclus�o da curva de transfer�ncia de polariza��o DC.
%-------------------------------------------------------------------------
%Formata��o num�rica
format short e %Cinco d�gitos mais expoente
%-------------------------------------------------------------------------
%Vari�veis de entrada
disp(' ')
Rs=input('Rs Fonte [ohm] - ZERO para desprezar: '); %Ex: 600
RL=input('Resistor de Carga [ohm] - Valor alto para desprezar: '); %Ex: 10e3
RG=input('Resistor de entrada RG [ohm]: '); %Ex: 1e6
disp('Op��es para o ganho:')
disp('0-> Ganho ac sem Rs e RL')
disp('1-> Ganho ac com RL')
disp('2-> Ganho ac com Rs e RL')
Ganho=input('Ganho: '); %Ex: 2
VGSoff=input('VGSoff em Volts: '); %Ex: -8
gfs0=input('Valor de gm para VGS=0V [S]. Obs:(gm=gfs=yfs): '); %Ex: 2000e-6
fmin=input('Freq. m�nima de corte  [Hz]: '); %Ex: 300
Vcc=input('Tens�o de alimenta��o [V]: '); %Ex: 12
Ptq=input('Pot�ncia de Trabalho do Transistor[W]: '); %Ex: 0.003
Crss=input('Crss: Capacit�ncia parasita entre dreno e gate[F]: '); %Ex: 3e-12
Ciss=input('Ciss: Common-Source Input Capacitance[F]: '); %Ex: 7e-12
Cstray=input('Capacit�ncia parasita de Fia��o [F]: '); %Ex: 8e-12
%-------------------------------------------------------------------------
%Constantes do sistema
K_Idss = 2;
Vds = 0.5;          %VDS 50% de Vcc
f1 = (1/10)*fmin;	%Frequ�ncia de corte a pardir da freq. de opera��o
%-------------------------------------------------------------------------
%Malha de s�ida
VDSq = Vds*Vcc;                     %VCE quiescente de opera��o do transistor
Id = Ptq/VDSq;                      %Corrente Id(dc) em fun��o da pot�ncia dissipada no transistor
Idss = K_Idss*Id;                        %Corrente Idss para colocar o ponto Q(dc) no centro da reta
VGS = -((sqrt(Id/Idss)-1)*VGSoff);  %Equa��o de Schotkey para VGS
VS = -VGS;                          %C�lculo de RS
RS = VS/Id;
PRS = VS*Id;                        %Pot�ncia em dissipada em RS
VRD = Vcc-VS-VDSq;                  %Tens�o em RD
RD = VRD/Id;                        %C�lculo de RD
PRD = VRD*Id;                       %Ptencia em RD
%-------------------------------------------------------------------------
%C�lculo AC
Zin = RG;
gm = gfs0*(1-(VGS/VGSoff));
rd = prl(RD,RL);

switch Ganho
    case 0                              %0-> Ganho ac sem Rs e RL 
        Av = gm*RD;                     %Ganho sem Rs       
    case 1                              %1-> Ganho ac com Rs 
        Av = gm*rd;                     %Ganho com RL        
    case 2                              %2-> Ganho ac com Rs e RL
        Avnl = gm*rd;                   %Ganho sem Rs
        Av = (Zin/(Zin+Rs))*Avnl;       %Ganho com Rs
end
Av_dB=20*log10(Av);
MPPsup = -Id*rd+VDSq;       	%Compliance de Corte Superior
%-------------------------------------------------------------------------
%Baixa frequ�ncia
R = Rs+Zin;			 
C1 = 1/((2*3.14)*R*f1); 	%C�lculo de C1
R = RL+RD; 
C2 = 1/((2*3.14)*R*f1); 	%C�lculo de C2
a = 1/gm;         
R = prl(RS,a);              %Aproxima��o desconsiderando os efeitos da
                            %resist�ncia interna de dreno do FET
CS = 1/((2*3.14)*R*f1); 	%C�lculo de CE
%-------------------------------------------------------------------------
%Alta frequ�ncia
CMin = Crss*(Av+1);                  %Capacit�ncia miller de entrada
Cout = (Crss*(Av+1)/Av)+Cstray;      %Capacit�ncia miller de s�ida + Capacit�ncia parasita de fia��o
Cgs = Ciss-Crss;                     %Capacit�ncia parasita de Emissor
Rin = prl(Rs,RG);
Cin=CMin+Cgs;                        %Capacit�ncia parasita total de entrada 
fc_in=1/(2*3.14*Rin*Cin);            %Frequ�ncia de corte superior pelo circuito de entrada
fc_out=1/(2*3.14*rd*Cout);           %Frequ�ncia de corte superior pelo circuito de sa�da

if (fc_in < fc_out)                  %Testa pra ver qual vai cortar primeiro
    fc_sup=fc_in;
else
    fc_sup=fc_out;
end

fmax=0.1*fc_sup;                     %Retorna a frequ�ncia m�xima da banda m�dia
%-------------------------------------------------------------------------
%Resultados
%disp('Resultados')

%C�lculo DC
disp(' ')
disp('C�lculo DC')
disp(['VDSq = ' num2str(VDSq)]) %Mostrar uma vari�vel ap�s uma string
disp(['Id = ' num2str(Id)])
disp(['RS = ' num2str(RS)])
disp(['RD = ' num2str(RD)])
disp(['RG = ' num2str(RG)])
disp(['Pot�ncia em RS = ' num2str(PRS)])
disp(['Pot�ncia em RD = ' num2str(PRD)])

%C�lculo AC
disp('C�lculo AC')
disp(['Zo = ' num2str(RD)])
disp(['Zin = ' num2str(Zin)])
disp(['Av(ac) = ' num2str(Av)])
disp(['Av(dB) = ' num2str(Av_dB)])
disp(['MPPsup = ' num2str(MPPsup)])
disp(['C1 = ' num2str(C1)])
disp(['C2 = ' num2str(C2)])
disp(['CS = ' num2str(CS)])
disp(['Frequ�ncia Max Banda = ' num2str(fmax)])

%Curvas
x = linspace(0,Vcc,2);
Id_sat = Vcc/(RD+RS);              %corrente de satura��o dc 
coef = Id_sat/Vcc;                 %coeficiente angular da reta cc
reta_cc = (-x*coef)+Id_sat;        %Eq da reta de carga

%A reta ca passa pelos pontos Q=`(Vce, Ie)*e*Corte_ca = (Ie*Rc_ac, 0)
coef_ca = Id/(Id*rd-VDSq);          %coeficiente angular da reta de carga ca
reta_ca = coef_ca*(x-VDSq)+Id; 
figure;                             %Abre outra janela de gr�fico
plot(x,reta_ca,x,reta_cc);
grid on;                            %Habilita grid do gr�fico
axis([0 Vcc 0 Id_sat]);             %Limite dos eixos
title('Reta de Carga');             %Formata��o do T�tulo
legend('ca','cc');                  %Formata��o da legenda das curvas
xlabel('VDS');                      %Formata��o do nome do eixo x
ylabel('Id');                       %Formata��o do nome do eixo y    

%Curva de transfer�ncia DC e ponto Q
a = linspace(VGSoff,0,10);          %Eixo x vai de VGSoff at� zero
yId = Idss*(1-(a/VGSoff)).^2;       %Eq Shockley para curva Vgs vs Id 
yRs = -1*(a/RS);                    %Eq para pol DC de entrada de gate
figure;                             %Abre outra janela de gr�fico
plot(a,yId,a,yRs);                  %Plota o gr�fico
grid on;                            %Habilita grid do gr�fico
title('Curva de transfer�ncia');    %Formata��o do T�tulo
legend('Dispositivo','Polariza��o');%Formata��o da legenda das curvas
xlabel('VDS');                      %Formata��o do nome do eixo x
ylabel('Id');                       %Formata��o do nome do eixo y   

