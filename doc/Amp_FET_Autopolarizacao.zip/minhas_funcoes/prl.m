%Fun��o 2 resistores em paralelo
%
%Retorna o valor de dois resistores em paralelo
%
%Exemplo
%
%resultado = prl(R1,R2)
%
%prl(10,5)

function resultado = prl(R1,R2)
resultado = (R1*R2)/(R1+R2);