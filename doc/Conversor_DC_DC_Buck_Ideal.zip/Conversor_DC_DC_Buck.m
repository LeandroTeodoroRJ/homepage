%-------------------------------------------------------------------------
%CONVERSOR DC-DC BUCK %ATZ 03/02/17
%-------------------------------------------------------------------------
%COMENT�RIOS
%*Tem como base o conversor DC-DC Buck do livro Eletr�nica de Pot�ncia
%an�lise e projetos de circuitos. Exemplo da pag. 206 e utilizando a 
%topologia inicial da Figura 6-3(a) da pag. 200. 
%*N�o contempla as pot�ncias dissipadas nos componentes n�o lineares.
%*N�o contempla as perdas por chaveamento.
%*As freq�ncias de trabalho normalmente s�o maiores que 20Khz
%*Falta o estudo e inclus�o da resist�ncia ac s�rie do capacitor pag. 207
%-------------------------------------------------------------------------
%Formata��o num�rica
format shortEng %Cinco d�gitos mais expoente
%-------------------------------------------------------------------------
%Vari�veis de entrada
disp(' ')
Vs=input('Tens�o DC de entrada[V]: '); 
VR=input('Tens�o DC de sa�da na carga[V]: '); 
f=input('Frequ�ncia da trabalho[Hz]: '); 
IL=input('Corrente na carga [A]: '); 
%-------------------------------------------------------------------------
%Constantes do sistema
%-------------------------------------------------------------------------
D_iL=0.75;      %Varia��o de corrente no indutor. T�pico 40%, valores 
                %menores de D_iL resultam em correntes de pico e rms no
                %indutor menores e menor corrente rms no capacitor. Mas
                %Requer um indutor maior.
D_VR=0.0047;    %Varia��o da tens�o na carga, valores t�picos menores
                %que 1%
%-------------------------------------------------------------------------
R1=VR/IL;                       %C�lculo do resistor de carga
D=VR/Vs;                        %C�lculo do Duty Cicle
t_on=D/f;                       %Tempo da chave ligada
t_off=(1/f)-t_on;               %Tempo da chave desligada
I_min=D_iL*IL;                  %Corrente m�nima no indutor
I_max=(1+D_iL)*IL;              %Corrente m�xima no indutor
L1=(VR*R1*(1-D))/(((I_max*R1)-VR)*2*f);   %Valor do indutor
C1=(1-D)/(8*L1*D_VR*(f^2));          %C�lculo do capacitor de filtro
%-------------------------------------------------------------------------
%Dados t�rmicos
%-------------------------------------------------------------------------
%Resultados
disp(' ')
disp('Resultados')
disp(['L1(H) = ' num2str(L1)])
disp(['C1[F] = ' num2str(C1)])
disp(['t_on[s] = ' num2str(t_on)])
disp(['t_off[s] = ' num2str(t_off)])
disp(['Duty Cicle = ' num2str(D)]) 
disp(['Corrente M�x no Indutor[A] = ' num2str(I_max)]) 
disp(['Corrente M�n no Indutor[A] = ' num2str(I_min)]) 


%-------------------------------------------------------------------------
%Curvas
                     